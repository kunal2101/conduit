package com.kk.conduit.ui.settings

import androidx.lifecycle.ViewModel

class SettingViewModel : ViewModel() {

}